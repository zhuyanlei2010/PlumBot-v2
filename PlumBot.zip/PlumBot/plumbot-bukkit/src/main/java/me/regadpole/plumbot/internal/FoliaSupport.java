package me.regadpole.plumbot.internal;

public class FoliaSupport {
    public static boolean isFolia;
}
