package sdk.listener;

public abstract class SimpleListener<T> extends EnableListener<T> {
}
